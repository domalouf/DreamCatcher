%TF.GenerationSoftware,KiCad,Pcbnew,7.0.11+dfsg-1build4*%
%TF.CreationDate,2026-11-14T03:58:53+00:00*%
%TF.ProjectId,dreamcatcher-eye-sensor,64726561-6d63-4617-9463-6865722d6579,1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.11+dfsg-1build4) date 2026-11-14 03:58:53*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.197500X0.632500X-0.197500X0.632500X0.197500X-0.632500X0.197500X-0.632500X-0.197500X0*%
%ADD11R,1.300000X1.300000*%
%ADD12C,1.300000*%
%ADD13RoundRect,0.218750X-0.218750X-0.256250X0.218750X-0.256250X0.218750X0.256250X-0.218750X0.256250X0*%
G04 APERTURE END LIST*
D10*
%TO.C,U1*%
X102000000Y-83400000D03*
X106000000Y-83400000D03*
X106000000Y-81600000D03*
X102000000Y-81600000D03*
%TD*%
D11*
%TO.C,J1*%
X101300000Y-88000000D03*
D12*
X103100000Y-88000000D03*
X104900000Y-88000000D03*
X106700000Y-88000000D03*
%TD*%
D13*
%TO.C,D1*%
X103212500Y-85500000D03*
X104787500Y-85500000D03*
%TD*%
M02*
